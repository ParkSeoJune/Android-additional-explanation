package com.example.android_book

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.android_book.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 뷰 바인딩을 사용할 준비
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        setContentView(R.layout.activity_main) // '콘텐츠를 화면에 표시하기 위해 res/layout 디렉터리 아래에 있는 activity_main.sml 파일을 사용한다' 라는 의미
        binding.btnSay.setOnClickListener {  // btnSay라는 아이디를 가진 버튼이 클릭되었을 때 이 괄호 안에 작성된 코드가 실행된다.
            binding.textSay.text = "Hello Kotlin!!!"
        }
    }
}