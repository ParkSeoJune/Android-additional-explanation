package com.example.Kotlin_basic.안드로이드_grammar

// 06. 연산자

// 산술 연산자
// +, -, *, /(몫만 취함), %(나머지만 취함)

// 대입 연산자
// 좌변 = 우변 (우변 값이 좌변에 들어간다)
// a = 5 (o), 5 = a (x)

// 복합 대입 연산자
// +=, -=, *=, /=, %=
// a += 10 ->  a = a + 10

// 증감 연산자
// ++, --
// a++, a--

// 비교 연산자
// >, >=, < <=, == !=
// True == True -> True
// True == False -> False
// True != True -> False
// True != False -> True

// 논리 연산자
// &&, ||, !
// True && True -> True
// True || False -> True
// !True -> False
// !False -> True
